﻿namespace MusicService.Application.Contracts.Dto.Music.GetAll
{
    public class GenreVm
    {
        public string Name { get; set; }
    }
}
